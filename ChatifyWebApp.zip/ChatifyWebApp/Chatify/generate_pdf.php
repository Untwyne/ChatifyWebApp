<?php
require"fpdf.php";

class myPDF extends FPDF{
    function header(){
        $this->Image('imgs/chatifylogo.png',10,6,60);
        $this->SetFont('Times','B',40);
        $this->Cell(276,5,'User Report Details',0,0,'C');
        $this->Ln();$this->Ln();$this->Ln();$this->Ln();$this->Ln();$this->Ln();$this->Ln();
    }

    function footer(){
        $this->SetY(-15);
        $this->SetFont('Times','',8);
        $this->Cell(0,10,'Page'.$this->PageNo().'{nb}',0,0,'C');
    }

    function headerTable(){
        $this->SetFont('Times','B',12);
        $this->Cell(40,10,'Full Name',1,0,'C');
        $this->Cell(40,10,'Username',1,0,'C');
        $this->Cell(50,10,'Email',1,0,'C');
        $this->Cell(30,10,'Subject',1,0,'C');
        $this->Cell(90,10,'Message',1,0,'C');
        $this->Cell(30,10,'Time',1,0,'C');
        $this->Ln();
    }

    function viewTable($db){
        $this->SetFont('Times','',12);
        $stmt = $db->query('select * from signup');
        while($data = $stmt->FETCH(PDO::FETCH_OBJ)){
            $this->Cell(40,10,$data->Fullname,1,0,'L');
            $this->Cell(40,10,$data->Username,1,0,'L');
            $this->Cell(50,10,$data->Email,1,0,'L'); 
        }
        $stmt = $db->query('select * from supportbox');
        while($data = $stmt->FETCH(PDO::FETCH_OBJ)){
            $this->Cell(30,10,$data->subject,1,0,'C');
            $this->Cell(90,10,$data->report,1,0,'C');
            $this->Cell(30,10,$data->r_time,1,0,'C');    
    }
  } 
}   


    $pdf = new myPDF();
    $pdf->AliasNbPages();
    $pdf->AddPage('L','A4',0);
    $pdf->headerTable();
    //$pdf->viewTable();
    $pdf->Output(); 
