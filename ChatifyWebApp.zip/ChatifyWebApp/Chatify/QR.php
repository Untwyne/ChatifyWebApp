<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
include("config/connect.php");
include("includes/fetch_users_info.php");
include ("includes/time_function.php");
include ("includes/num_k_m_count.php");

include('phpqrcode/qrlib.php');

$tempDir=_DIR_;

$codeContents='https://isims.heart-nta.org/';

//$fileName='005_file_'.md5($codeContents).'.png';
$fileName= "Qr_code.png";

$pngAbsoluteFilePath =  $tempDir.$fileName;
$urlRelativeFilePath = _DIR_.$fileName;

if(!file_exists($pngAbsoluteFilePath)) {
    QRcode::png($codeContents, $pngAbsoluteFilePath);
    echo 'File generated!';
    echo'<hr />';
}
else {
    echo 'File already generated! We can use this cached file to speed up site on common codes!';
    echo '<hr />';
}

echo 'Server PNG File:'.$pngAbsoluteFilePath;
echo '<hr />';

echo'<img src="../Chatify'.$fileName.'"/>';



if(!isset($_SESSION['Username'])){
    header("location: index");