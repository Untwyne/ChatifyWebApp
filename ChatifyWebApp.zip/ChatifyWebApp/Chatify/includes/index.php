<?php
header("location: ../home");
?>