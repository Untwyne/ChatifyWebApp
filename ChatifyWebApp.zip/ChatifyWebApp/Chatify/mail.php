<?php
    $con = mysqli_connect("localhost", "Username", "Password");
    if (!$con){
      die('Could not connect: ' . mysqli_error());
    }

    $db_selected = mysqli_select_db("chatify",$con);
    $sql = "SELECT Fullname_Username_Email FROM signup";
    $result = mysqli_query($sql,$con);

    while ($row_data = mysqli_fetch_array($result)) {

        // Then you will set your variables for the e-mail using the data 
        // from the array.

        $from = 'chatifywebapp@gmail.com';
        $to = $row_data['Email']; // The column where your e-mail was stored.
        $subject = 'Welcome to Chatify';
        $msg = 'Thank you for joining the Chatify family.Chatify is a social network platform helps you meet new friends and stay connected with your family and with who you are interested anytime anywhere.';
        mail($to, $subject, $msg, $from);
    }
?>